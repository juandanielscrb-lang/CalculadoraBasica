#declaramos el nombre de la base y aseguramos que sea nueva
CREATE DATABASE IF NOT EXISTS Lectura_Viva;
#una vez revisado que no existe la vamos a utilizar
USE Lectura_Viva;

#vamos a crear la primera tabla independiente a partir del MER
CREATE TABLE IF NOT EXISTS categorias(
Id_categoria INT UNIQUE PRIMARY KEY,
Nombre_categoria VARCHAR(50) NOT NULL
);

#vamos a crear la segunda tabla independiente a partir del MER																																																																														#vamos a crear la segunda tabla independiente a partir del MER
CREATE TABLE IF NOT EXISTS autores(
Id_autor INT UNIQUE PRIMARY KEY,
Nombre_autor VARCHAR(50) NOT NULL,
Nacionalidad_autor VARCHAR(30) NULL
);

#vamos a crear la tercera tabla independiente a partir del MER
CREATE TABLE IF NOT EXISTS clientes(
Id_cliente INT UNIQUE PRIMARY KEY,
Nombre_cliente VARCHAR(50) NOT NULL,
Correo_cliente VARCHAR(50) NOT NULL
);

#vamos a crear la primera tabla dependiente a partir del MER
CREATE TABLE IF NOT EXISTS libros(
Id_libro INT UNIQUE PRIMARY KEY,
Titulo_libro VARCHAR(50) NOT NULL,
Año_Publicacion_libro DATE NOT NULL,
Precio_libro FLOAT(10,2) NOT NULL,
Id_categoria INT NOT NULL,

CONSTRAINT fk_libro_categoria FOREIGN KEY (Id_categoria) REFERENCES categorias(Id_categoria) 
);																																																																													#vamos a crear la segunda tabla independiente a partir del MER

#vamos a crear la segunda tabla dependiente a partir del MER
CREATE TABLE IF NOT EXISTS facturas(
Id_factura INT UNIQUE PRIMARY KEY,
Fecha_factura DATE NOT NULL,
Total_factura FLOAT(10,2) NOT NULL,
Id_cliente INT NOT NULL,

CONSTRAINT fk_factura_cliente FOREIGN KEY (Id_cliente) REFERENCES clientes(Id_cliente) 
);

#vamos a crear la tercera tabla dependiente a partir del MER
CREATE TABLE IF NOT EXISTS libros_autores(
Id_autor_libro INT UNIQUE PRIMARY KEY,
Id_libro INT NOT NULL,
Id_autor INT NOT NULL,

CONSTRAINT fk_libros_autores_libro FOREIGN KEY (Id_libro) REFERENCES libros(Id_libro),
CONSTRAINT fk_libros_autores_autor FOREIGN KEY (Id_autor) REFERENCES autores(Id_autor)
);

#vamos a crear la cuarta tabla dependiente a partir del MER
CREATE TABLE IF NOT EXISTS detallesfacturas(
Id_detallefactura INT UNIQUE PRIMARY KEY,
Cantidad_detallesfactura INT NOT NULL,
Subtotal_detallesfactura INT NOT NULL,
Id_factura INT NOT NULL,
Id_libro INT NOT NULL,

CONSTRAINT fk_detallesfacturas_factura FOREIGN KEY (Id_factura) REFERENCES facturas(Id_factura),
CONSTRAINT fk_detallesfacturas_libro FOREIGN KEY (Id_libro) REFERENCES libros(Id_libro)
);


